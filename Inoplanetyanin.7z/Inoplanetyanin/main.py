import pygame
import random
import sys
from button import Button
pygame.init()

SCREEN_SIZE = SCREEN_WIDTH, SCREEN_HEIGHT = 1000, 750
screen = pygame.display.set_mode(SCREEN_SIZE, pygame.RESIZABLE)
clock = pygame.time.Clock()

all_sprite = pygame.sprite.Group()
meteors = pygame.sprite.Group()

player = pygame.sprite.Sprite(all_sprite)
player.image = pygame.image.load('./images/alien.png')
player.rect = player.image.get_rect()

player.rect.x = 0 # задаем координату Х центра спрайта
player.rect.y = 0 # задаем координату Y центра спрайта

coin = pygame.sprite.Sprite(all_sprite)
coin.image = pygame.image.load('./images/coin.png')
coin.rect = coin.image.get_rect()

coin.rect.x = 150
coin.rect.y = 150

speed = 5
speed_meteor = 10


pygame.mixer.music.load('./audio/flight.mp3')

meteor_sound = pygame.mixer.Sound('./audio/meteor.mp3')

time_count = 0
health = 3
points = 0
start_time = 0
font_object = pygame.font.SysFont('dejavuserif', 48)

def spawn_meteor():
    meteor = pygame.sprite.Sprite(all_sprite, meteors)
    image_index = random.randint(1, 6)
    if image_index <= 3:
        image_indexs = 1
    elif image_index <= 5:
        image_indexs = 2
    else:
        image_indexs = 3
    meteor.image = pygame.image.load(f'./images/meteors/meteor{image_indexs}.png')
    meteor.rect = meteor.image.get_rect()
    meteor.rect.x = random.randint(
    meteor.rect.width // 2, SCREEN_WIDTH - meteor.rect.width // 2
    )
    meteor.rect.y = -150

def main_menu():
    font = pygame.font.Font(None, 74)
    text_surface = font.render("ALIEN", True, (255, 255, 255))
    text_rect = text_surface.get_rect()
    text_rect.centerx = SCREEN_WIDTH // 2
    text_rect.y = 10

    start = Button(SCREEN_WIDTH // 2 - 100, 200, 100, 50, "Старт", game(),(252, 17, 0), (252, 67, 0))

    run = True
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                start.process_events(event)

        start.update()
        screen.blit(text_surface, text_rect)
        start.draw()
        pygame.display.update()
    
def finish():
    global points, start_time
    text1 = font_object.render(f'Конец игры!', False, 'blue')
    text2 = font_object.render(f'Счет: {points}. Время: {round((pygame.time.get_ticks() - start_time) / 1000, 2)}', False, 'blue')
    text3 = font_object.render(f'Нажмите N чобы начать заново', False, 'blue')

    lines = []
    with open("res.txt", "r", encoding="UTF-8") as file:
        lines = file.read().split("\n")
        
        if int(lines[0]) < points:
            lines[0] = points
        if float((lines[1])) < round((pygame.time.get_ticks() - start_time) / 1000, 2):
            lines[1] = round((pygame.time.get_ticks() - start_time) / 1000, 2)
        lines[4] = lines[3]
        lines[3] = lines[2]
        lines[2] = points, (pygame.time.get_ticks() - start_time) / 1000
        lines.pop(5)
        print(lines)
    with open("res.txt", "w", encoding="UTF-8") as file:
        for line in lines:
            file.write(str(line))
            file.write("\n")

    run = True
    while run:
        

        screen.fill((0, 0, 64))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                


        screen.blit(text1, (SCREEN_WIDTH/2-100, SCREEN_HEIGHT/2-150))
        screen.blit(text2, (SCREEN_WIDTH/2-100, SCREEN_HEIGHT/2-100))

        pygame.display.update()
        clock.tick(60)

def game():
    pygame.mixer.music.play(-1)
    pygame.mixer.music.set_volume(0.3)
    global start_time, coin, speed, points, player, font_object, health, time_count, meteor_sound
    run = True
    while run:
        if points >= 50:
            screen.fill((9, 189, 174))
        elif points >= 30:
            screen.fill((232, 68, 14))
        elif points >= 20:
            screen.fill((125, 4, 48))
        elif points >= 10:
            screen.fill((3, 150, 82))
        else:
            screen.fill((0, 0, 64))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                sys.exit()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_a]:
            if player.rect.x >= speed:
                player.rect.x -= speed
        if keys[pygame.K_d]:
            if player.rect.x <= SCREEN_WIDTH - 130 - speed:
                player.rect.x += speed
        if keys[pygame.K_w]:
            if player.rect.y >= speed:
                player.rect.y -= speed
        if keys[pygame.K_s]:
            if player.rect.y <= SCREEN_HEIGHT- 190 - speed:
                player.rect.y += speed
        if keys[pygame.K_UP]:
                if 0 > speed < 10:
                    speed += 1
        if keys[pygame.K_DOWN]:
                if 0 > speed < 10:
                    speed -= 1

        all_sprite.draw(screen)

        if pygame.sprite.collide_mask(player, coin):
            import random
            coin.rect.x = random.randint(0,SCREEN_WIDTH-128)
            coin.rect.y = random.randint(48,SCREEN_HEIGHT-128)
            points += 1
            if points == 1:
                start_time = pygame.time.get_ticks()

        for meteor in meteors:
            meteor.rect.y += speed_meteor
            if meteor.rect.top == 0:
                meteor_sound.play(1)
            if meteor.rect.bottom == SCREEN_HEIGHT:
                meteor_sound.stop()
                meteor.kill()
            if pygame.sprite.collide_mask(player, meteor):
                health -= 1
                meteor.kill()
        if health <= 0:
            finish()
            run = False
            pygame.mixer.music.stop()
        
        

              
        time_count += 1
        if time_count % 90 == 0:
            spawn_meteor()

        text = font_object.render(f'Монеток: {points}', False, 'black', 'gold')
        screen.blit(text, (5,5))

        if points > 0:
            text = font_object.render(f'Осталось: {60 - (round((pygame.time.get_ticks() - start_time)/1000))} секунд', False, 'black', 'gold')
            screen.blit(text, (350,5))

        health_png = pygame.image.load(f"./images/health/h_{health}.png")
        screen.blit(health_png, (SCREEN_WIDTH-100, SCREEN_HEIGHT-100))

        if pygame.time.get_ticks() - start_time > 60000:
            run = False 
            finish()
            run = False

        pygame.display.update()
        
        clock.tick(60)

run = True
while run:

    game()
    run = False
pygame.quit()