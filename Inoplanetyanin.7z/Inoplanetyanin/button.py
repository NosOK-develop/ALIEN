import pygame

# Инициализация Pygame (необходима перед использованием шрифтов и т.д.)
pygame.init()

class Button:
    def __init__(self, x, y, width, height, text, on_click_function, normal_color, hover_color, pressed_color, font_size=35):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.on_click_function = on_click_function
        self.colors = {
            'normal': normal_color,
            'hover': hover_color,
            'pressed': pressed_color,
        }
        self.current_color = self.colors['normal']
        self.rect = pygame.Rect(x, y, width, height)
        
        # Настройка текста
        self.font = pygame.font.SysFont(None, font_size)
        self.text = text
        self.text_surf = self.font.render(text, True, (20, 20, 20)) # Цвет текста - темно-серый
        self.text_rect = self.text_surf.get_rect(center=(self.x + self.width/2, self.y + self.height/2))

    def process_events(self, event):
        """Обрабатывает события Pygame для кнопки."""
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.current_color = self.colors['pressed']
                if self.on_click_function:
                    self.on_click_function()
        elif event.type == pygame.MOUSEBUTTONUP:
            if self.rect.collidepoint(event.pos):
                self.current_color = self.colors['hover'] # Вернуться к цвету наведения
            else:
                self.current_color = self.colors['normal'] # Вернуться к нормальному цвету

    def update(self):
        """Обновляет состояние кнопки (например, при наведении курсора)."""
        mouse_pos = pygame.mouse.get_pos()
        if self.rect.collidepoint(mouse_pos):
            if pygame.mouse.get_pressed()[0] == 0: # Если кнопка мыши не зажата
                self.current_color = self.colors['hover']
        else:
            self.current_color = self.colors['normal']

    def draw(self, surface):
        """Отрисовывает кнопку на поверхности."""
        pygame.draw.rect(surface, self.current_color, self.rect)
        surface.blit(self.text_surf, self.text_rect)
