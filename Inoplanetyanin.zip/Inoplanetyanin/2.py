import pygame
import random
import sys

pygame.init()

SCREEN_SIZE = SCREEN_WIDTH, SCREEN_HEIGHT = 1000, 750
screen = pygame.display.set_mode(SCREEN_SIZE, pygame.RESIZABLE)
clock = pygame.time.Clock()

all_sprite = pygame.sprite.Group()
meteors = pygame.sprite.Group()

player = pygame.sprite.Sprite(all_sprite)
player.image = pygame.image.load('alien.png')
player.rect = player.image.get_rect()

player.rect.x = 0 # задаем координату Х центра спрайта
player.rect.y = 0 # задаем координату Y центра спрайта

coin = pygame.sprite.Sprite(all_sprite)
coin.image = pygame.image.load('coin.png')
coin.rect = coin.image.get_rect()

coin.rect.x = 150
coin.rect.y = 150

speed = 5
speed_meteor = 10


time_count = 0
health = 3
points = 0
start_time = 0
font_object = pygame.font.SysFont('dejavuserif', 48)

def spawn_meteor():
    meteor = pygame.sprite.Sprite(all_sprite, meteors)
    meteor.image = pygame.image.load(f'./meteors/meteor.png')
    meteor.rect = meteor.image.get_rect()
    meteor.rect.x = random.randint(
    0, SCREEN_WIDTH - meteor.rect.width // 4
    )
    meteor.rect.y = -150


def finish():
    global points, start_time
    text1 = font_object.render(f'Конец игры!', False, 'blue')
    text2 = font_object.render(f'Счет: {points}', False, 'blue')
    text3 = font_object.render(f'Нажмите N чобы начать заново', False, 'blue')

    run = True
    while run:
        screen.fill((0, 0, 64))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                


        screen.blit(text1, (SCREEN_WIDTH/2-100, SCREEN_HEIGHT/2-150))
        screen.blit(text2, (SCREEN_WIDTH/2-100, SCREEN_HEIGHT/2-100))
        screen.blit(text2, (SCREEN_WIDTH/2-100, SCREEN_HEIGHT/2-50))

        pygame.display.update()
        clock.tick(60)

def game():
    global start_time, coin, speed, points, player, font_object, health, time_count
    run = True
    while run:

        screen.fill((0, 0, 64))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                sys.exit()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_a]:
            if player.rect.x >= speed:
                player.rect.x -= speed
        if keys[pygame.K_d]:
            if player.rect.x <= SCREEN_WIDTH - 130 - speed:
                player.rect.x += speed
        if keys[pygame.K_w]:
            if player.rect.y >= speed:
                player.rect.y -= speed
        if keys[pygame.K_s]:
            if player.rect.y <= SCREEN_HEIGHT- 190 - speed:
                player.rect.y += speed
        if keys[pygame.K_UP]:
                if 0 > speed < 10:
                    speed += 1
        if keys[pygame.K_DOWN]:
                if 0 > speed < 10:
                    speed -= 1

        all_sprite.draw(screen)

        if pygame.sprite.collide_mask(player, coin):
            import random
            coin.rect.x = random.randint(0,SCREEN_WIDTH-128)
            coin.rect.y = random.randint(48,SCREEN_HEIGHT-128)
            points += 1
            if points == 1:
                start_time = pygame.time.get_ticks()

        for meteor in meteors:
            meteor.rect.y += speed_meteor
            if meteor.rect.top == SCREEN_HEIGHT:
                meteor.kill()
            if pygame.sprite.collide_mask(player, meteor):
                health -= 1
        if health <= 0:
            finish()
            run = False
        
        
        if pygame.time.get_ticks() - start_time > 60000:
            run = False 
            finish()
            run = False
              
        time_count += 1
        if time_count % 60 == 0:
            spawn_meteor()

        text = font_object.render(f'Монеток: {points}', False, 'black', 'gold')
        screen.blit(text, (5,5))

        if points > 0:
            text = font_object.render(f'Осталось: {60 - (round((pygame.time.get_ticks() - start_time)/1000))} секунд', False, 'black', 'gold')
            screen.blit(text, (350,5))

        pygame.display.update()
        
        clock.tick(60)

run = True
while run:

    game()
    run = False
pygame.quit()